﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.CSharp;
using System.Reflection;


namespace NonlinearSolve_Lab4a_
{
    class Program
    {
        static void Main(string[] args)
        {
            //f(x)=x^4-4x^3-2x-2, a=-1, b=0;



            double a=-1, b=0, c=(a+b)/2, eps=1e-5;
            int count = 0;

            string func = "Math.Pow(a,4)-4*Math.Pow(a,3)-2*a-2;";

            string source = 
@"
using System;
class f
{
    public static double Func(double a)
    {
        return " + func + @"
        }
}   

";


            CodeDomProvider codeProvider = new CSharpCodeProvider();
            CompilerParameters compilerParams = new CompilerParameters();

            compilerParams.CompilerOptions = "/target:library";

            compilerParams.GenerateExecutable = false;
            compilerParams.GenerateInMemory = true;
            compilerParams.IncludeDebugInformation = false;
            compilerParams.ReferencedAssemblies.Add("System.dll");

            CompilerResults results = codeProvider.CompileAssemblyFromSource(compilerParams, source);

            foreach(CompilerError err in results.Errors)
            {
                Console.WriteLine(err.ErrorText);
            }

            Assembly asm = results.CompiledAssembly;

            Type t = asm.GetType("f");

            while (b - a > 2 * eps)
            {
                double Fa = (double)t.InvokeMember("Func", BindingFlags.Static | BindingFlags.Public | BindingFlags.InvokeMethod, null, null, new object[] { a });
                double Fc = (double)t.InvokeMember("Func", BindingFlags.Static | BindingFlags.Public | BindingFlags.InvokeMethod, null, null, new object[] { c });

                if (Fa * Fc > 0)
                    a = c;
                else
                    b = c;
                c = (a + b) / 2;
                count++;
            }

            Console.WriteLine("X :" + c + "\n Кол-во итераций : " + count);

        }
    }

   
}
